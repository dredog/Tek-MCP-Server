@echo off
setlocal enabledelayedexpansion

REM ============================================================================
REM Tektronix MCP Server v1.0 + Tek PTA - Windows Installer
REM ============================================================================

echo.
echo ============================================================
echo    Tektronix MCP Server v1.0 + Tek PTA Installer
echo ============================================================
echo.

set "INSTALL_DIR=%USERPROFILE%\TektronixMCP"
set "CLAUDE_CONFIG=%APPDATA%\Claude\claude_desktop_config.json"

echo Installation directory: %INSTALL_DIR%
echo.

REM ============================================================
REM Check Python version (requires 3.10+ for MCP packages)
REM ============================================================
echo [1/6] Checking Python...

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found!
    echo Please install Python 3.10 or later from https://python.org
    echo Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

REM Get Python version
for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYVER=%%i
echo        Found Python %PYVER%

REM Extract major.minor version
for /f "tokens=1,2 delims=." %%a in ("%PYVER%") do (
    set PYMAJOR=%%a
    set PYMINOR=%%b
)

REM Check Python 3.10+ requirement
if %PYMAJOR% LSS 3 (
    echo ERROR: Python 3.10+ required for MCP server, found %PYVER%
    echo.
    echo The MCP server packages require Python 3.10 or later.
    echo Download from: https://python.org
    pause
    exit /b 1
)
if %PYMAJOR%==3 if %PYMINOR% LSS 10 (
    echo ERROR: Python 3.10+ required for MCP server, found %PYVER%
    echo.
    echo The MCP server packages require Python 3.10 or later.
    echo Download from: https://python.org
    echo.
    echo TIP: If you only need Tek PTA (without Claude integration^),
    echo      run INSTALL_TekPTA_Standalone.bat instead (Python 3.9+^)
    pause
    exit /b 1
)
echo        Python version OK

REM ============================================================
REM Create directories
REM ============================================================
echo [2/6] Creating directories...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%\docs" mkdir "%INSTALL_DIR%\docs"
if not exist "%INSTALL_DIR%\docs\instrument_commands_json" mkdir "%INSTALL_DIR%\docs\instrument_commands_json"
if not exist "%INSTALL_DIR%\docs\python_examples" mkdir "%INSTALL_DIR%\docs\python_examples"
if not exist "%INSTALL_DIR%\PTA" mkdir "%INSTALL_DIR%\PTA"
if not exist "%INSTALL_DIR%\PTA\test_suites" mkdir "%INSTALL_DIR%\PTA\test_suites"
if not exist "%APPDATA%\Claude" mkdir "%APPDATA%\Claude"
echo        Done

REM ============================================================
REM Copy files (NO venv - always create fresh)
REM ============================================================
echo [3/6] Copying files...

REM Copy main MCP server files
copy /Y "%~dp0tektronix_mcp_server.py" "%INSTALL_DIR%\" >nul 2>&1
copy /Y "%~dp0requirements.txt" "%INSTALL_DIR%\" >nul 2>&1
copy /Y "%~dp0README.md" "%INSTALL_DIR%\" >nul 2>&1

REM Copy JSON command databases
if exist "%~dp0docs\instrument_commands_json" (
    xcopy /E /I /Y "%~dp0docs\instrument_commands_json\*" "%INSTALL_DIR%\docs\instrument_commands_json\" >nul 2>&1
)

REM Copy markdown documentation files
if exist "%~dp0docs\*.md" (
    copy /Y "%~dp0docs\*.md" "%INSTALL_DIR%\docs\" >nul 2>&1
)

REM Copy Python examples (golden examples for search)
if exist "%~dp0docs\python_examples" (
    xcopy /E /I /Y "%~dp0docs\python_examples\*" "%INSTALL_DIR%\docs\python_examples\" >nul 2>&1
)

REM Copy Tek PTA files
if exist "%~dp0PTA" (
    xcopy /E /I /Y "%~dp0PTA\*" "%INSTALL_DIR%\PTA\" >nul 2>&1
)

echo        Done

REM ============================================================
REM Create fresh virtual environment
REM ============================================================
echo [4/6] Creating virtual environment...
echo        (Creating fresh venv for your Python version)

REM Remove old venv if it exists
if exist "%INSTALL_DIR%\venv" (
    echo        Removing old virtual environment...
    rmdir /s /q "%INSTALL_DIR%\venv" >nul 2>&1
)

REM Create new venv
python -m venv "%INSTALL_DIR%\venv"
if errorlevel 1 (
    echo ERROR: Failed to create virtual environment
    pause
    exit /b 1
)
echo        Virtual environment created

REM ============================================================
REM Install dependencies
REM ============================================================
echo [5/6] Installing dependencies...
call "%INSTALL_DIR%\venv\Scripts\activate.bat"

pip install --upgrade pip >nul 2>&1

REM Install MCP server dependencies
echo        Installing MCP server packages...
pip install mcp fastmcp pydantic openai pyvisa pyvisa-py >nul 2>&1

REM Install Tek PTA dependencies
echo        Installing Tek PTA packages...
pip install Pillow reportlab matplotlib >nul 2>&1

if errorlevel 1 (
    echo WARNING: Some packages may have failed to install
    echo You can manually run: pip install -r requirements.txt
)
echo        Done

REM ============================================================
REM Configure Claude Desktop
REM ============================================================
echo [6/6] Configuring Claude Desktop...

REM Write Python config script to temp file
set "TEMP_SCRIPT=%TEMP%\tek_config_claude.py"

(
echo import json, os
echo.
echo config_path = r'%CLAUDE_CONFIG%'
echo install_dir = r'%INSTALL_DIR%'
echo.
echo config = {'mcpServers': {}}
echo old_api_key = ''
echo old_vector_id = ''
echo.
echo if os.path.exists(config_path^):
echo     try:
echo         with open(config_path, 'r'^) as f:
echo             content = f.read(^).strip(^)
echo             if content:
echo                 config = json.loads(content^)
echo                 if 'mcpServers' in config and 'tektronix' in config['mcpServers']:
echo                     env = config['mcpServers']['tektronix'].get('env', {}^)
echo                     old_api_key = env.get('OPENAI_API_KEY', ''^)
echo                     old_vector_id = env.get('TEK_VECTOR_STORE_ID', ''^)
echo                     if old_api_key and not old_api_key.startswith('YOUR'^):
echo                         print('        Preserving existing API key'^)
echo                     if old_vector_id and not old_vector_id.startswith('YOUR'^):
echo                         print('        Preserving existing vector store ID'^)
echo     except:
echo         pass
echo.
echo if 'mcpServers' not in config:
echo     config['mcpServers'] = {}
echo.
echo env = {'TEK_INSTALL_PATH': install_dir}
echo env['OPENAI_API_KEY'] = old_api_key if (old_api_key and not old_api_key.startswith('YOUR'^)^) else 'YOUR_API_KEY_HERE'
echo env['TEK_VECTOR_STORE_ID'] = old_vector_id if (old_vector_id and not old_vector_id.startswith('YOUR'^)^) else 'YOUR_VECTOR_STORE_ID_HERE'
echo.
echo python_exe = os.path.join(install_dir, 'venv', 'Scripts', 'python.exe'^)
echo server_script = os.path.join(install_dir, 'tektronix_mcp_server.py'^)
echo.
echo config['mcpServers']['tektronix'] = {
echo     'command': python_exe,
echo     'args': [server_script],
echo     'env': env
echo }
echo.
echo with open(config_path, 'w'^) as f:
echo     json.dump(config, f, indent=2^)
echo.
echo print('        Claude Desktop configured'^)
) > "%TEMP_SCRIPT%"

REM Run the Python script
python "%TEMP_SCRIPT%"

REM Clean up temp file
del "%TEMP_SCRIPT%" >nul 2>&1

echo.
echo ============================================================
echo    Installation Complete!
echo ============================================================
echo.
echo Location: %INSTALL_DIR%
echo.
echo INSTALLED COMPONENTS:
echo   [x] Tektronix MCP Server (for Claude Desktop)
echo   [x] SCPI Command Databases (16,000+ commands)
echo   [x] Documentation (markdown guides)
echo   [x] Python Golden Examples (searchable code samples)
echo   [x] Tek PTA - Production Test Assistant (standalone GUI)
echo.
echo NEXT STEPS:
echo.
echo 1. (Optional) Add OpenAI API key for enhanced search:
echo    Edit: %CLAUDE_CONFIG%
echo    Change OPENAI_API_KEY and TEK_VECTOR_STORE_ID
echo.
echo 2. Restart Claude Desktop completely (quit and reopen)
echo.
echo 3. Test MCP: Ask Claude "What is your Tektronix MCP server status?"
echo.
echo 4. Run Tek PTA: Double-click %INSTALL_DIR%\PTA\Run_TekPTA.bat
echo.
pause
