@echo off
REM ============================================================
REM  Tek Wake Listener Launcher
REM  Edit the settings below, then double-click to run
REM ============================================================

REM --- Your instrument address ---
set TEK_INSTRUMENT=TCPIP::169.254.10.36::INSTR

REM --- Your Anthropic API key (for complex voice commands) ---
set ANTHROPIC_API_KEY=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

REM --- Microphone index (run with --list-mics to find yours) index 3 is the laptop speaker, index 1 is my headset---
set MIC_INDEX=9

REM --- Speech engine: google, whisper, or vosk ---
set STT_ENGINE=google

REM --- Voice feedback: set to --tts to enable, or leave blank ---
set TTS_FLAG=

REM --- Verbose mode: set to --verbose to see all recognized speech ---
set VERBOSE_FLAG=--verbose

REM ============================================================
REM  Don't edit below this line
REM ============================================================

echo.
echo  Starting Tek Wake Listener...
echo  Instrument: %TEK_INSTRUMENT%
echo  Mic index:  %MIC_INDEX%
echo  Engine:     %STT_ENGINE%
echo.

python tek_wake_listener.py --instrument %TEK_INSTRUMENT% --claude-api-key %ANTHROPIC_API_KEY% --mic-index %MIC_INDEX% --engine %STT_ENGINE% %TTS_FLAG% %VERBOSE_FLAG%

if %ERRORLEVEL% neq 0 (
    echo.
    echo  Something went wrong. Check the error above.
    echo.
)
pause
