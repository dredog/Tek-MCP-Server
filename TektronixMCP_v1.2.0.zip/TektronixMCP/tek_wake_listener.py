#!/usr/bin/env python3
"""
Tek Wake Listener v1.0.0
========================
Always-on voice command listener for Tektronix instrument control.

Uses "Hey Tek" as the wake phrase. After detecting the wake phrase,
captures the spoken command and either:
  1. Executes it directly via PyVISA (for critical/fast commands like run/stop)
  2. Sends it to Claude API for interpretation into SCPI (for complex commands)

INSTALLATION
============
Required:
    pip install SpeechRecognition pyaudio pyvisa pyvisa-py anthropic

Voice feedback (scope talks back):
    pip install pyttsx3

    Platform-specific TTS backends:
      Windows: Uses SAPI5 (built-in, no extra install)
      macOS:   Uses NSSpeechSynthesizer (built-in)
      Linux:   sudo apt-get install espeak (or espeak-ng)

Optional (for better offline recognition):
    pip install vosk
    # Download a vosk model from https://alphacephei.com/vosk/models
    # Place in models/vosk-model-small-en-us-0.15/ (or set VOSK_MODEL_PATH)

Optional (for local Whisper):
    pip install openai-whisper

Platform Notes:
    Windows: pip install pyaudio
    macOS:   brew install portaudio && pip install pyaudio
    Linux:   sudo apt-get install portaudio19-dev python3-pyaudio && pip install pyaudio

USAGE
=====
    # Basic usage (uses Google STT, requires internet)
    python tek_wake_listener.py --instrument TCPIP::192.168.1.100::INSTR

    # With Claude API for complex commands
    python tek_wake_listener.py --instrument TCPIP::192.168.1.100::INSTR --claude-api-key sk-ant-...

    # With voice feedback (scope talks back!)
    python tek_wake_listener.py --instrument TCPIP::192.168.1.100::INSTR --tts

    # Full setup: Claude + voice feedback + custom speech rate
    python tek_wake_listener.py -i TCPIP::192.168.1.100::INSTR --claude-api-key sk-ant-... --tts --tts-rate 150

    # With Vosk offline recognition
    python tek_wake_listener.py --instrument TCPIP::192.168.1.100::INSTR --engine vosk

    # List available microphones or TTS voices
    python tek_wake_listener.py --list-mics
    python tek_wake_listener.py --list-voices

VOICE COMMANDS
==============
Quick commands (executed directly, sub-second response):
    "Hey Tek, run"                    → Start acquisition
    "Hey Tek, stop"                   → Stop acquisition
    "Hey Tek, single"                 → Single acquisition
    "Hey Tek, autoset"                → Run autoset
    "Hey Tek, screenshot"             → Save screenshot
    "Hey Tek, channel 1 on"           → Enable CH1
    "Hey Tek, channel 2 off"          → Disable CH2
    "Hey Tek, force trigger"          → Force a trigger event
    "Hey Tek, clear"                  → Clear status/measurements
    "Hey Tek, default setup"          → Reset to defaults (*RST)
    "Hey Tek, what's the frequency"   → Query MEAS1 frequency
    "Hey Tek, scale up"               → Increase vertical scale
    "Hey Tek, scale down"             → Decrease vertical scale
    "Hey Tek, zoom in"                → Decrease horizontal scale (zoom in)
    "Hey Tek, zoom out"               → Increase horizontal scale (zoom out)

Complex commands (sent to Claude API for interpretation):
    "Hey Tek, set up SPI decode on channels 1 and 2"
    "Hey Tek, configure for 1 GHz jitter measurement"
    "Hey Tek, why is my signal clipping"

Author: Tektronix Automation Team
License: MIT
"""

import os
import sys
import re
import json
import time
import signal
import argparse
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Callable, Tuple

# =============================================================================
# OPTIONAL IMPORTS
# =============================================================================

try:
    import speech_recognition as sr
    SR_AVAILABLE = True
except ImportError:
    SR_AVAILABLE = False

try:
    import pyvisa
    PYVISA_AVAILABLE = True
except ImportError:
    PYVISA_AVAILABLE = False

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

# Optional: Text-to-speech for voice feedback
try:
    import pyttsx3
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False

# =============================================================================
# CONFIGURATION
# =============================================================================

# Wake phrase variants (all lowercase for matching)
WAKE_PHRASES = [
    "hey tek",
    "hey tech",
    "hey tec",
    "hey text",     # Common misrecognition
    "a tek",        # Truncated recognition
    "hey tektronix",
    "hey tekk",
]

# How long to listen for the command after wake phrase (seconds)
COMMAND_LISTEN_TIMEOUT = 5

# Audio settings
ENERGY_THRESHOLD = 300        # Ambient noise threshold (auto-adjusted)
PAUSE_THRESHOLD = 0.8         # Seconds of silence to end a phrase
PHRASE_TIME_LIMIT = 10        # Max seconds to listen for a single phrase

# =============================================================================
# QUICK COMMAND MAP
# =============================================================================
# Maps spoken phrases to (SCPI_command, is_query, description) tuples.
# These execute directly via PyVISA for sub-second response.
# Patterns are matched in order - first match wins.

QUICK_COMMANDS: list[Tuple[list[str], str, bool, str]] = [
    # (phrase_patterns, scpi_command, is_query, description)
    
    # Acquisition control
    (["run", "start", "go"],
     "ACQ:STATE RUN", False, "Acquisition running"),
    
    (["stop", "halt", "freeze", "hold"],
     "ACQ:STATE STOP", False, "Acquisition stopped"),
    
    (["single", "single shot", "one shot", "single acquisition"],
     "ACQ:STOPA SEQ;:ACQ:STATE RUN", False, "Single acquisition triggered"),
    
    (["force trigger", "force", "force trig"],
     "TRIGger FORCe", False, "Trigger forced"),
    
    (["autoset", "auto set", "auto setup", "auto"],
     "AUTOS EXECUTE", False, "Autoset executing..."),
    
    # Reset and clear
    (["default setup", "reset", "factory reset", "defaults"],
     "*RST", False, "Reset to defaults"),
    
    (["clear", "clear status", "clear errors"],
     "*CLS", False, "Status cleared"),
    
    # Screenshot
    (["screenshot", "screen shot", "screen capture", "capture screen", "take a picture",
      "save screen", "grab screen"],
     "SAVe:IMAGe:FILEFormat PNG;:HARDCopy START", False, "Screenshot captured"),
    
    # Channel enable/disable
    (["channel 1 on", "ch1 on", "enable channel 1", "turn on channel 1",
      "show channel 1", "channel one on"],
     "DISplay:WAVEView1:CH1:STATE ON", False, "Channel 1 enabled"),
    
    (["channel 1 off", "ch1 off", "disable channel 1", "turn off channel 1",
      "hide channel 1", "channel one off"],
     "DISplay:WAVEView1:CH1:STATE OFF", False, "Channel 1 disabled"),
    
    (["channel 2 on", "ch2 on", "enable channel 2", "turn on channel 2",
      "show channel 2", "channel two on"],
     "DISplay:WAVEView1:CH2:STATE ON", False, "Channel 2 enabled"),
    
    (["channel 2 off", "ch2 off", "disable channel 2", "turn off channel 2",
      "hide channel 2", "channel two off"],
     "DISplay:WAVEView1:CH2:STATE OFF", False, "Channel 2 disabled"),
    
    (["channel 3 on", "ch3 on", "enable channel 3", "channel three on"],
     "DISplay:WAVEView1:CH3:STATE ON", False, "Channel 3 enabled"),
    
    (["channel 3 off", "ch3 off", "disable channel 3", "channel three off"],
     "DISplay:WAVEView1:CH3:STATE OFF", False, "Channel 3 disabled"),
    
    (["channel 4 on", "ch4 on", "enable channel 4", "channel four on"],
     "DISplay:WAVEView1:CH4:STATE ON", False, "Channel 4 enabled"),
    
    (["channel 4 off", "ch4 off", "disable channel 4", "channel four off"],
     "DISplay:WAVEView1:CH4:STATE OFF", False, "Channel 4 disabled"),
    
    # Quick measurements
    (["what's the frequency", "whats the frequency", "read frequency",
      "measure frequency", "get frequency", "frequency"],
     "MEASUrement:MEAS1:RESUlts:CURRentacq:MEAN?", True, "Frequency"),
    
    (["what's the amplitude", "whats the amplitude", "read amplitude",
      "measure amplitude", "amplitude"],
     "MEASUrement:MEAS1:RESUlts:CURRentacq:MEAN?", True, "Amplitude"),
    
    # Vertical scale adjustments
    (["scale up", "increase scale", "bigger", "more scale"],
     "_SCALE_UP", False, "Scale increased"),
    
    (["scale down", "decrease scale", "smaller", "less scale"],
     "_SCALE_DOWN", False, "Scale decreased"),
    
    # Horizontal zoom
    (["zoom in", "zoom", "closer", "more detail"],
     "_ZOOM_IN", False, "Zoomed in"),
    
    (["zoom out", "wider", "less detail", "more time"],
     "_ZOOM_OUT", False, "Zoomed out"),
    
    # Status queries
    (["status", "what's happening", "state", "instrument state"],
     "_STATUS_QUERY", True, "Status"),
    
    (["clipping", "is it clipping", "am i clipping", "check clipping"],
     "CH1:CLIPping?", True, "Clipping check"),
]


# =============================================================================
# INSTRUMENT CONTROLLER
# =============================================================================

class InstrumentController:
    """Manages direct PyVISA communication for quick commands."""
    
    def __init__(self, resource_string: str, timeout_ms: int = 30000):
        self.resource_string = resource_string
        self.timeout_ms = timeout_ms
        self.session = None
        self.rm = None
        self.idn = ""
        self.lock = threading.Lock()
    
    def connect(self) -> bool:
        """Open VISA session to instrument."""
        if not PYVISA_AVAILABLE:
            print("ERROR: PyVISA not installed")
            return False
        
        try:
            self.rm = pyvisa.ResourceManager()
            self.session = self.rm.open_resource(self.resource_string)
            self.session.timeout = self.timeout_ms
            self.session.write("*CLS")
            self.session.write("HEADer OFF")
            self.session.write("VERBose OFF")
            self.idn = self.session.query("*IDN?").strip()
            return True
        except Exception as e:
            print(f"ERROR connecting to {self.resource_string}: {e}")
            return False
    
    def disconnect(self):
        """Close VISA session."""
        if self.session:
            try:
                self.session.close()
            except:
                pass
            self.session = None
    
    def write(self, command: str) -> bool:
        """Send SCPI command."""
        if not self.session:
            return False
        try:
            with self.lock:
                # Handle compound commands with semicolons
                for cmd in command.split(";:"):
                    cmd = cmd.strip().lstrip(":")
                    if cmd:
                        self.session.write(cmd)
            return True
        except Exception as e:
            print(f"  VISA write error: {e}")
            return False
    
    def query(self, command: str) -> Optional[str]:
        """Send SCPI query and return response."""
        if not self.session:
            return None
        try:
            with self.lock:
                return self.session.query(command).strip()
        except Exception as e:
            print(f"  VISA query error: {e}")
            return None
    
    def execute_special(self, command_key: str) -> str:
        """Handle special (non-SCPI) commands like scale adjustments."""
        
        if command_key == "_SCALE_UP":
            # Read current scale, multiply by 2
            scale = self.query("CH1:SCAle?")
            if scale:
                new_scale = float(scale) * 2
                self.write(f"CH1:SCAle {new_scale}")
                return f"CH1 scale: {scale} → {new_scale} V/div"
            return "Could not read current scale"
        
        elif command_key == "_SCALE_DOWN":
            scale = self.query("CH1:SCAle?")
            if scale:
                new_scale = float(scale) / 2
                self.write(f"CH1:SCAle {new_scale}")
                return f"CH1 scale: {scale} → {new_scale} V/div"
            return "Could not read current scale"
        
        elif command_key == "_ZOOM_IN":
            scale = self.query("HOR:SCAle?")
            if scale:
                new_scale = float(scale) / 2
                self.write(f"HOR:SCAle {new_scale}")
                return f"Timebase: {scale} → {new_scale} s/div"
            return "Could not read current timebase"
        
        elif command_key == "_ZOOM_OUT":
            scale = self.query("HOR:SCAle?")
            if scale:
                new_scale = float(scale) * 2
                self.write(f"HOR:SCAle {new_scale}")
                return f"Timebase: {scale} → {new_scale} s/div"
            return "Could not read current timebase"
        
        elif command_key == "_STATUS_QUERY":
            parts = []
            acq = self.query("ACQ:STATE?")
            parts.append(f"Acquisition: {'Running' if acq == '1' else 'Stopped'}")
            hor = self.query("HOR:SCAle?")
            parts.append(f"Timebase: {hor} s/div")
            for ch in range(1, 5):
                state = self.query(f"DISplay:WAVEView1:CH{ch}:STATE?")
                if state == "1":
                    scale = self.query(f"CH{ch}:SCAle?")
                    parts.append(f"CH{ch}: {scale} V/div")
            return " | ".join(parts)
        
        return "Unknown special command"


# =============================================================================
# CLAUDE API INTEGRATION
# =============================================================================

class ClaudeCommander:
    """Sends complex voice commands to Claude API for SCPI interpretation."""
    
    def __init__(self, api_key: str, instrument_resource: str, model: str = "claude-sonnet-4-20250514"):
        self.client = None
        self.model = model
        self.instrument_resource = instrument_resource
        
        if ANTHROPIC_AVAILABLE and api_key:
            self.client = anthropic.Anthropic(api_key=api_key)
    
    def interpret_command(self, spoken_command: str, instrument_idn: str = "") -> Optional[str]:
        """Send a complex voice command to Claude for SCPI interpretation.
        
        Returns the SCPI commands to execute, or a natural language response.
        """
        if not self.client:
            return None
        
        system_prompt = f"""You are a Tektronix oscilloscope automation assistant.
The user is controlling a {instrument_idn or 'Tektronix oscilloscope'} via voice commands.
Convert their spoken request into SCPI commands.

RULES:
1. Return ONLY verified SCPI commands from the MSO 4/5/6 Series Programmer Manual
2. One command per line, no explanations unless the command is ambiguous
3. If the request is a question (e.g., "why is my signal clipping?"), provide a brief 
   answer with any relevant SCPI queries to investigate
4. If you cannot determine the SCPI commands, say so clearly
5. Prefix queries (commands ending in ?) with QUERY: so the system knows to read the response
6. Prefix informational responses with INFO: 

Example input: "set channel 1 to 500 millivolts per div, 50 ohms"
Example output:
CH1:SCAle 500E-3
CH1:TERMinator 50

Example input: "why am I seeing ringing"
Example output:
INFO: Ringing often indicates impedance mismatch. Check these:
QUERY: CH1:TERMinator?
QUERY: CH1:BANdwidth?
INFO: Try setting 50 ohm termination or adding a bandwidth limit.
"""
        
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=500,
                system=system_prompt,
                messages=[
                    {"role": "user", "content": f"Voice command: {spoken_command}"}
                ]
            )
            return response.content[0].text.strip()
        except Exception as e:
            print(f"  Claude API error: {e}")
            return None


# =============================================================================
# AUDIO / SPEECH RECOGNITION
# =============================================================================

class VoiceListener:
    """Manages microphone input and speech-to-text."""
    
    def __init__(self, engine: str = "google", mic_index: Optional[int] = None,
                 vosk_model_path: Optional[str] = None):
        self.engine = engine
        self.mic_index = mic_index
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = ENERGY_THRESHOLD
        self.recognizer.pause_threshold = PAUSE_THRESHOLD
        self.recognizer.dynamic_energy_threshold = True
        self.vosk_model_path = vosk_model_path
        
        # Set up microphone
        if mic_index is not None:
            self.microphone = sr.Microphone(device_index=mic_index)
        else:
            self.microphone = sr.Microphone()
    
    def calibrate(self, duration: float = 2.0):
        """Calibrate for ambient noise."""
        print(f"  Calibrating for ambient noise ({duration}s)...")
        with self.microphone as source:
            self.recognizer.adjust_for_ambient_noise(source, duration=duration)
        print(f"  Energy threshold set to: {self.recognizer.energy_threshold:.0f}")
    
    def listen_once(self, timeout: Optional[float] = None,
                    phrase_time_limit: Optional[float] = None) -> Optional[str]:
        """Listen for a single phrase and return the transcription.
        
        Args:
            timeout: Max seconds to wait for speech to start (None = wait forever)
            phrase_time_limit: Max seconds of speech to capture
            
        Returns:
            Transcribed text (lowercase) or None if nothing recognized
        """
        try:
            with self.microphone as source:
                audio = self.recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=phrase_time_limit or PHRASE_TIME_LIMIT
                )
            
            # Transcribe based on engine
            if self.engine == "google":
                text = self.recognizer.recognize_google(audio)
            elif self.engine == "whisper":
                text = self.recognizer.recognize_whisper(audio, model="base.en")
            elif self.engine == "vosk":
                if self.vosk_model_path:
                    text = self.recognizer.recognize_vosk(audio, model_path=self.vosk_model_path)
                    # Vosk returns JSON
                    try:
                        result = json.loads(text)
                        text = result.get("text", "")
                    except:
                        pass
                else:
                    text = self.recognizer.recognize_vosk(audio)
                    try:
                        result = json.loads(text)
                        text = result.get("text", "")
                    except:
                        pass
            else:
                text = self.recognizer.recognize_google(audio)
            
            return text.lower().strip() if text else None
            
        except sr.WaitTimeoutError:
            return None
        except sr.UnknownValueError:
            return None
        except sr.RequestError as e:
            print(f"  STT service error: {e}")
            return None
        except Exception as e:
            print(f"  Listen error: {e}")
            return None


# =============================================================================
# MAIN APPLICATION
# =============================================================================

class TekWakeListener:
    """Main application: always-listening voice controller for Tektronix instruments."""
    
    def __init__(self, instrument_resource: str, claude_api_key: str = "",
                 stt_engine: str = "google", mic_index: Optional[int] = None,
                 vosk_model_path: Optional[str] = None, tts_enabled: bool = False,
                 tts_rate: int = 175, tts_voice: str = "", verbose: bool = False):
        
        self.instrument = InstrumentController(instrument_resource)
        self.claude = ClaudeCommander(claude_api_key, instrument_resource)
        self.voice = VoiceListener(stt_engine, mic_index, vosk_model_path)
        self.running = False
        self.command_count = 0
        self.has_claude = bool(claude_api_key and ANTHROPIC_AVAILABLE)
        self.verbose = verbose
        
        # Text-to-speech setup
        self.tts_enabled = tts_enabled and TTS_AVAILABLE
        self.tts_engine = None
        self.tts_lock = threading.Lock()
        
        if self.tts_enabled:
            try:
                self.tts_engine = pyttsx3.init()
                self.tts_engine.setProperty('rate', tts_rate)
                
                # Set voice if specified, otherwise pick a reasonable default
                voices = self.tts_engine.getProperty('voices')
                if tts_voice:
                    for v in voices:
                        if tts_voice.lower() in v.name.lower() or tts_voice.lower() in v.id.lower():
                            self.tts_engine.setProperty('voice', v.id)
                            break
                # Prefer a female voice if available and no preference given
                elif voices and len(voices) > 1:
                    # Index 1 is typically the female voice on most platforms
                    self.tts_engine.setProperty('voice', voices[1].id)
                    
            except Exception as e:
                print(f"  WARNING: TTS initialization failed: {e}")
                self.tts_enabled = False
                self.tts_engine = None
    
    def start(self):
        """Initialize connections and start the listen loop."""
        print("\n" + "=" * 60)
        print("🎤 Tek Wake Listener v1.0.0")
        print("=" * 60)
        
        # Connect to instrument
        print(f"\n📡 Connecting to {self.instrument.resource_string}...")
        if not self.instrument.connect():
            print("❌ Cannot connect to instrument. Check the resource string and try again.")
            return False
        
        parts = self.instrument.idn.split(",")
        model = parts[1].strip() if len(parts) > 1 else "Unknown"
        serial = parts[2].strip() if len(parts) > 2 else ""
        print(f"✅ Connected: {model} ({serial})")
        
        # Calibrate microphone
        print(f"\n🎙️  Setting up microphone (engine: {self.voice.engine})...")
        self.voice.calibrate()
        
        # Status
        print(f"\n{'─' * 60}")
        print(f"🟢 LISTENING for 'Hey Tek' commands")
        print(f"   Instrument: {model}")
        if self.has_claude:
            print(f"   Claude API: ✅ Enabled (complex commands supported)")
        else:
            print(f"   Claude API: ❌ Disabled (quick commands only)")
        if self.tts_enabled:
            voice_name = "default"
            try:
                vid = self.tts_engine.getProperty('voice')
                for v in self.tts_engine.getProperty('voices'):
                    if v.id == vid:
                        voice_name = v.name
                        break
            except:
                pass
            print(f"   Voice feedback: 🔊 Enabled ({voice_name})")
        else:
            print(f"   Voice feedback: 🔇 Disabled (use --tts to enable)")
        print(f"   Say 'Hey Tek, <command>' to control the scope")
        if self.verbose:
            print(f"   Verbose mode: 🔊 ON (showing all recognized speech)")
        print(f"   Press Ctrl+C to exit")
        print(f"{'─' * 60}\n")
        
        self.running = True
        
        # Announce readiness via TTS
        if self.tts_enabled:
            self._speak_feedback(f"Connected to {model}. Listening for commands.")
        
        self._listen_loop()
        return True
    
    def stop(self):
        """Shut down the listener."""
        self.running = False
        self.instrument.disconnect()
        if self.tts_engine:
            try:
                self.tts_engine.stop()
            except:
                pass
        print(f"\n👋 Tek Wake Listener stopped. {self.command_count} commands executed.")
    
    def _detect_wake_phrase(self, text: str) -> Optional[str]:
        """Check if text starts with a wake phrase and extract the command.
        
        Returns the command portion (after the wake phrase) or None.
        """
        text_lower = text.lower().strip()
        
        for phrase in WAKE_PHRASES:
            if text_lower.startswith(phrase):
                command = text_lower[len(phrase):].strip().lstrip(",").strip()
                return command
        
        return None
    
    def _match_quick_command(self, command: str) -> Optional[Tuple[str, bool, str]]:
        """Match a spoken command against the quick command map.
        
        Returns (scpi_command, is_query, description) or None.
        """
        command_lower = command.lower().strip()
        
        for patterns, scpi, is_query, description in QUICK_COMMANDS:
            for pattern in patterns:
                if pattern in command_lower or command_lower.startswith(pattern):
                    return (scpi, is_query, description)
        
        return None
    
    def _execute_quick_command(self, scpi: str, is_query: bool, description: str):
        """Execute a quick command directly via PyVISA."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        # Handle special commands
        if scpi.startswith("_"):
            result = self.instrument.execute_special(scpi)
            print(f"  [{timestamp}] ⚡ {description}: {result}")
            self._speak_feedback(f"{description}. {result}")
            return
        
        if is_query:
            response = self.instrument.query(scpi)
            if response:
                print(f"  [{timestamp}] 📊 {description}: {response}")
                self._speak_feedback(f"{description}: {response}")
            else:
                print(f"  [{timestamp}] ❌ Query failed: {scpi}")
                self._speak_feedback("Query failed")
        else:
            success = self.instrument.write(scpi)
            if success:
                print(f"  [{timestamp}] ✅ {description}")
                self._speak_feedback(description)
                
                # Special delay for autoset
                if "AUTOS" in scpi:
                    time.sleep(5)
                    print(f"  [{timestamp}] ✅ Autoset complete")
            else:
                print(f"  [{timestamp}] ❌ Command failed: {scpi}")
                self._speak_feedback("Command failed")
    
    def _execute_claude_command(self, spoken_command: str):
        """Send a complex command to Claude API for interpretation."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        print(f"  [{timestamp}] 🤖 Sending to Claude: \"{spoken_command}\"")
        
        response = self.claude.interpret_command(spoken_command, self.instrument.idn)
        
        if not response:
            print(f"  [{timestamp}] ❌ Claude could not interpret the command")
            self._speak_feedback("Sorry, I couldn't interpret that command")
            return
        
        print(f"  [{timestamp}] 🤖 Claude response:")
        
        # Parse and execute the response
        for line in response.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            
            if line.startswith("INFO:"):
                info = line[5:].strip()
                print(f"         ℹ️  {info}")
                self._speak_feedback(info)
            
            elif line.startswith("QUERY:"):
                query_cmd = line[6:].strip()
                result = self.instrument.query(query_cmd)
                print(f"         📊 {query_cmd} → {result}")
            
            elif line.startswith("#") or line.startswith("//"):
                # Skip comments
                continue
            
            else:
                # Assume it's a SCPI command
                if "?" in line:
                    result = self.instrument.query(line)
                    print(f"         📊 {line} → {result}")
                else:
                    success = self.instrument.write(line)
                    status = "✓" if success else "✗"
                    print(f"         {status} {line}")
        
        # Sync
        self.instrument.query("*OPC?")
        print(f"  [{timestamp}] ✅ Claude commands executed")
        self._speak_feedback("Done")
    
    def _speak_feedback(self, text: str):
        """Provide audio feedback via text-to-speech.
        
        Runs TTS in a separate thread so it doesn't block the listen loop.
        If TTS is disabled, this is a no-op.
        """
        if not self.tts_enabled or not self.tts_engine:
            return
        
        # Keep responses concise for voice - truncate long responses
        if len(text) > 200:
            text = text[:200] + "..."
        
        def _speak():
            try:
                with self.tts_lock:
                    self.tts_engine.say(text)
                    self.tts_engine.runAndWait()
            except Exception as e:
                print(f"  TTS error: {e}")
        
        # Run in thread to avoid blocking
        tts_thread = threading.Thread(target=_speak, daemon=True)
        tts_thread.start()
    
    def _listen_loop(self):
        """Main listen loop - runs until stopped."""
        while self.running:
            try:
                # Listen for any speech (blocking, no timeout = wait forever)
                text = self.voice.listen_once(timeout=None)
                
                if not text:
                    if self.verbose:
                        print(f"  [verbose] (heard audio but no transcription)")
                    continue
                
                # Show everything the recognizer hears in verbose mode
                if self.verbose:
                    timestamp = datetime.now().strftime("%H:%M:%S")
                    print(f"  [{timestamp}] 👂 Heard: \"{text}\"")
                
                # Check for wake phrase
                command = self._detect_wake_phrase(text)
                
                if command is None:
                    # No wake phrase detected - ignore
                    if self.verbose:
                        print(f"           (no wake phrase match)")
                    continue
                
                # Wake phrase detected!
                timestamp = datetime.now().strftime("%H:%M:%S")
                self.command_count += 1
                
                if not command:
                    # Wake phrase only, no command yet - listen for command
                    print(f"  [{timestamp}] 🎤 Wake phrase detected, listening for command...")
                    command = self.voice.listen_once(
                        timeout=COMMAND_LISTEN_TIMEOUT,
                        phrase_time_limit=PHRASE_TIME_LIMIT
                    )
                    if not command:
                        print(f"  [{timestamp}] ⏳ No command heard after wake phrase")
                        continue
                
                print(f"  [{timestamp}] 🗣️  Command: \"{command}\"")
                
                # Try quick command match first
                quick = self._match_quick_command(command)
                
                if quick:
                    scpi, is_query, description = quick
                    self._execute_quick_command(scpi, is_query, description)
                
                elif self.has_claude:
                    # Complex command - send to Claude
                    self._execute_claude_command(command)
                
                else:
                    print(f"  [{timestamp}] ❓ Unknown command: \"{command}\"")
                    print(f"           (Claude API not configured for complex commands)")
                    self._speak_feedback("Unknown command. Try run, stop, single, or autoset.")
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"  Error in listen loop: {e}")
                time.sleep(1)  # Avoid tight loop on persistent errors


# =============================================================================
# CLI
# =============================================================================

def list_microphones():
    """List available audio input devices."""
    if not SR_AVAILABLE:
        print("ERROR: SpeechRecognition not installed. Run: pip install SpeechRecognition")
        return
    
    print("\n🎙️  Available Microphones:")
    print("─" * 40)
    
    for i, name in enumerate(sr.Microphone.list_microphone_names()):
        print(f"  [{i}] {name}")
    
    print(f"\nUse --mic-index <number> to select a specific microphone.")


def main():
    parser = argparse.ArgumentParser(
        description="Tek Wake Listener - Voice control for Tektronix instruments",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --instrument TCPIP::192.168.1.100::INSTR
  %(prog)s --instrument TCPIP::192.168.1.100::INSTR --tts
  %(prog)s --instrument TCPIP::192.168.1.100::INSTR --claude-api-key sk-ant-... --tts
  %(prog)s --instrument USB::0x0699::INSTR --engine whisper --tts --tts-rate 150
  %(prog)s --list-mics
  %(prog)s --list-voices
        """
    )
    
    parser.add_argument(
        "--instrument", "-i",
        default=os.environ.get("TEK_INSTRUMENT", ""),
        help="VISA resource string (e.g., TCPIP::192.168.1.100::INSTR). "
             "Can also set TEK_INSTRUMENT env variable."
    )
    
    parser.add_argument(
        "--claude-api-key",
        default=os.environ.get("ANTHROPIC_API_KEY", ""),
        help="Anthropic API key for complex commands. "
             "Can also set ANTHROPIC_API_KEY env variable."
    )
    
    parser.add_argument(
        "--engine", "-e",
        choices=["google", "whisper", "vosk"],
        default="google",
        help="Speech recognition engine (default: google)"
    )
    
    parser.add_argument(
        "--mic-index", "-m",
        type=int, default=None,
        help="Microphone device index (see --list-mics)"
    )
    
    parser.add_argument(
        "--vosk-model",
        default=os.environ.get("VOSK_MODEL_PATH", ""),
        help="Path to Vosk model directory (for offline recognition)"
    )
    
    parser.add_argument(
        "--list-mics",
        action="store_true",
        help="List available microphones and exit"
    )
    
    parser.add_argument(
        "--tts",
        action="store_true",
        default=False,
        help="Enable voice feedback (scope talks back). Requires: pip install pyttsx3"
    )
    
    parser.add_argument(
        "--tts-rate",
        type=int, default=175,
        help="Speech rate in words per minute (default: 175). Lower = slower."
    )
    
    parser.add_argument(
        "--tts-voice",
        default="",
        help="TTS voice name filter (e.g., 'zira', 'david', 'samantha'). "
             "Partial match on voice name. Default picks a female voice if available."
    )
    
    parser.add_argument(
        "--list-voices",
        action="store_true",
        help="List available TTS voices and exit"
    )
    
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        default=False,
        help="Show everything the recognizer hears (for debugging mic/recognition issues)"
    )
    
    args = parser.parse_args()
    
    # List microphones
    if args.list_mics:
        list_microphones()
        return
    
    # List TTS voices
    if args.list_voices:
        if not TTS_AVAILABLE:
            print("ERROR: pyttsx3 not installed. Run: pip install pyttsx3")
            return
        try:
            engine = pyttsx3.init()
            voices = engine.getProperty('voices')
            print("\n🔊 Available TTS Voices:")
            print("─" * 50)
            for i, v in enumerate(voices):
                print(f"  [{i}] {v.name}")
                print(f"      ID: {v.id}")
                if v.languages:
                    print(f"      Languages: {v.languages}")
            print(f"\nUse --tts-voice <name> to select (partial match supported).")
            engine.stop()
        except Exception as e:
            print(f"ERROR initializing TTS: {e}")
        return
    
    # Check dependencies
    if not SR_AVAILABLE:
        print("ERROR: SpeechRecognition not installed.")
        print("  Install: pip install SpeechRecognition pyaudio")
        sys.exit(1)
    
    if not PYVISA_AVAILABLE:
        print("ERROR: PyVISA not installed.")
        print("  Install: pip install pyvisa pyvisa-py")
        sys.exit(1)
    
    if not args.instrument:
        print("ERROR: No instrument specified.")
        print("  Use: --instrument TCPIP::192.168.1.100::INSTR")
        print("  Or set: TEK_INSTRUMENT=TCPIP::192.168.1.100::INSTR")
        sys.exit(1)
    
    if args.engine == "vosk" and not args.vosk_model:
        print("WARNING: Vosk engine selected but no model path specified.")
        print("  Download models from: https://alphacephei.com/vosk/models")
        print("  Use --vosk-model /path/to/model")
    
    if args.tts and not TTS_AVAILABLE:
        print("WARNING: --tts enabled but pyttsx3 not installed.")
        print("  Install: pip install pyttsx3")
        print("  Continuing without voice feedback.\n")
    
    # Create and start listener
    listener = TekWakeListener(
        instrument_resource=args.instrument,
        claude_api_key=args.claude_api_key,
        stt_engine=args.engine,
        mic_index=args.mic_index,
        vosk_model_path=args.vosk_model if args.vosk_model else None,
        tts_enabled=args.tts,
        tts_rate=args.tts_rate,
        tts_voice=args.tts_voice,
        verbose=args.verbose,
    )
    
    # Handle Ctrl+C gracefully
    def signal_handler(sig, frame):
        listener.stop()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    
    # Start
    if not listener.start():
        sys.exit(1)


if __name__ == "__main__":
    main()
